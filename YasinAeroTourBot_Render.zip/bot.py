from telegram import ReplyKeyboardMarkup, Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
TOKEN="PASTE_YOUR_BOT_TOKEN"
MENU=[["✈️ Turlar","🛂 Vizalar"],["🏨 Mehmonxonalar","🔥 Issiq takliflar"],["🎁 Aksiyalar","📞 Menejer bilan bog'lanish"]]
async def start(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Assalomu alaykum! Yasin Aero Tour botiga xush kelibsiz.",reply_markup=ReplyKeyboardMarkup(MENU,resize_keyboard=True))
async def msg(update:Update, context:ContextTypes.DEFAULT_TYPE):
    r={"✈️ Turlar":"Turlar bo'yicha menejer bog'lanadi.","🛂 Vizalar":"Qaysi davlat vizasi kerak?","🏨 Mehmonxonalar":"Mehmonxona tanlashda yordam beramiz.","🔥 Issiq takliflar":"Issiq takliflar tez orada.","🎁 Aksiyalar":"Aksiyalar tez orada.","📞 Menejer bilan bog'lanish":"+998 XX XXX XX XX"}
    await update.message.reply_text(r.get(update.message.text,"Menyudan tanlang."))
app=Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start",start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,msg))
app.run_polling()
